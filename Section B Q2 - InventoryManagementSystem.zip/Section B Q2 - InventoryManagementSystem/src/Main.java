// Main Class
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        InventoryManager manager = new InventoryManager();
        int choice;

        do {
            System.out.println("1. Add Product");
            System.out.println("2. Search Product");
            System.out.println("3. Delete Product");
            System.out.println("4. Display Inventory");
            System.out.println("5. Exit");
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    System.out.print("Enter Product ID: ");
                    String id = scanner.next();
                    System.out.print("Enter Product Name: ");
                    String name = scanner.next();
                    System.out.print("Enter Quantity: ");
                    int qty = scanner.nextInt();
                    System.out.print("Enter Price: ");
                    double price = scanner.nextDouble();
                    Product product = new Product(id, name, qty, price);
                    manager.addProduct(product);
                    break;
                case 2:
                    System.out.print("Enter Product ID to search: ");
                    String searchId = scanner.next();
                    Product foundProduct = manager.searchProduct(searchId);
                    if (foundProduct != null) {
                        System.out.println("Product found: " + foundProduct);
                    }
                    break;
                case 3:
                    System.out.print("Enter Product ID to delete: ");
                    String deleteId = scanner.next();
                    manager.deleteProduct(deleteId);
                    break;
                case 4:
                    manager.displayInventory();
                    break;
                case 5:
                    System.out.println("Exiting application...");
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        } while (choice != 5);

        scanner.close();
    }
}
