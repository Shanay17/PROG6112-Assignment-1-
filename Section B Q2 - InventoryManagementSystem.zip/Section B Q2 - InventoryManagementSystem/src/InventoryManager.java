// InventoryManager Class
import java.util.ArrayList;

public class InventoryManager {
    private ArrayList<Product> products = new ArrayList<>();

    public void addProduct(Product product) {
        products.add(product);
        System.out.println("Product added successfully.");
    }

    public Product searchProduct(String productID) {
        for (Product product : products) {
            if (product.getProductID().equals(productID)) {
                return product;
            }
        }
        System.out.println("Product not found.");
        return null;
    }

    public void deleteProduct(String productID) {
        Product product = searchProduct(productID);
        if (product != null) {
            products.remove(product);
            System.out.println("Product removed successfully.");
        }
    }

    public void displayInventory() {
        System.out.println("Inventory Report:");
        for (Product product : products) {
            System.out.println(product);
        }
    }
}
