public class Student {
    private String studentID;
    private String name;
    private int age;
    private String email;
    private String course;

    // Constructor
    public Student(String studentID, String name, int age, String email, String course) {
        this.studentID = studentID;
        this.name = name;
        this.age = age;
        this.email = email;
        this.course = course;
    }

    // Getters and Setters
    public String getStudentID() { return studentID; }
    public void setStudentID(String studentID) { this.studentID = studentID; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public int getAge() { return age; }
    public void setAge(int age) { this.age = age; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getCourse() { return course; }
    public void setCourse(String course) { this.course = course; }

    // Define methods to perform actions
    public static void saveStudent(Student student, ArrayList<Student> students) {
        students.add(student);
        System.out.println("Student details saved successfully!");
    }

    public static Student searchStudent(String studentID, ArrayList<Student> students) {
        for (Student student : students) {
            if (student.getStudentID().equals(studentID)) {
                return student;
            }
        }
        System.out.println("Student not found.");
        return null;
    }

    public static void deleteStudent(String studentID, ArrayList<Student> students) {
        Student student = searchStudent(studentID, students);
        if (student != null) {
            students.remove(student);
            System.out.println("Student deleted successfully.");
        } else {
            System.out.println("Student not found.");
        }
    }

    public static void generateStudentReport(ArrayList<Student> students) {
        System.out.println("Student Report:");
        for (Student student : students) {
            System.out.println(student.toString());
        }
    }

    @Override
    public String toString() {
        return "Student ID: " + studentID + ", Name: " + name + ", Age: " + age + ", Email: " + email + ", Course: " + course;
    }
}
